from setuptools import setup

setup(name='probability_distributions_2023',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['probability_distributions_2023'],
      author='Karankumar Patel',
      author_email='patelkaran0496@gmail.com',
      zip_safe=False)
